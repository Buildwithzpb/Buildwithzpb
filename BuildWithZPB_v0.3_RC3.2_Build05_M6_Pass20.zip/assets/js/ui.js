// Shared UI placeholder
