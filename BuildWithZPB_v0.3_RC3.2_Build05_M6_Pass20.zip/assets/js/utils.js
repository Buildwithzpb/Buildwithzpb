// Shared utilities placeholder
